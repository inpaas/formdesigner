/**
 * Auto-generated comment stub
 *
  * @inpaas.key studiov2.js.constants.icons
 * @inpaas.name Icons
 * @inpaas.type source.static.js
 * @inpaas.engine Nashorn
 * @inpaas.anonymous false
*/

angular
  .module('studio-v2')
  .constant('ICONS', [
  {class: 'fa-pencil'},
  {class: 'fa-user-o'},
  {class: 'fa-question'},
  {class: 'fa-info'},
  {class: 'fa-address-book'},
  {class: 'fa-play'}
]);