/**
 * Auto-generated comment stub
 *
  * @inpaas.key studiov2.js.services.fieldValidation.finder
 * @inpaas.name FieldValidation | Finder
 * @inpaas.type source.static.js
 * @inpaas.engine Nashorn
 * @inpaas.anonymous false
*/

angular
  .module('studio-v2')
  .service('FieldValidationFinder', FieldValidationFinder)

FieldValidationFinder.$inject = ['FieldValidationDataSource']

function FieldValidationFinder(FieldValidationDataSource) {
  this.validate = validate;

  function validate(field, config){
    FieldValidationDataSource.validate(field, config); 
  }
}