/**
 * Auto-generated comment stub
 *
  * @inpaas.key studiov2.js.services.fieldValidation.select
 * @inpaas.name FieldValidation | Select
 * @inpaas.type source.static.js
 * @inpaas.engine Nashorn
 * @inpaas.anonymous false
*/

angular
  .module('studio-v2')
  .service('FieldValidationSelect', FieldValidationSelect)

FieldValidationSelect.$inject = ['FieldValidationDataSource']

function FieldValidationSelect(FieldValidationDataSource) {
  this.validate = validate;

  function validate(field, config){
    FieldValidationDataSource.validate(field, config); 
  }
}